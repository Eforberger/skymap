

import pyfits as fits
import sys
import Tkinter as tk
import tkFileDialog as filedialog


import datetime
from datetime import *

def openFile():
    fits2txt(str(filedialog.askopenfilename()))
    
def fits2txt(file):
	
	
    hdulist = fits.open(file)
    hdulist.info()
    
    
    
    print(hdulist[1].header)
    
    tbdata = hdulist[1].data

    textfile = open("fermidataformatted.txt", "w")
    
    
    for n in range(len(tbdata)):
        time = ((timedelta(seconds=float(tbdata[n][9])) + datetime(2001,1,1))-datetime(1970,1,1)).total_seconds()
        
        textfile.write("dec " + str(tbdata[n][3]) + " ra " + str(tbdata[n][2]) + " err 0 type null kind gamma_ray energy " + str(tbdata[n][1]) + " time " + str(time) + " flux null spec null\n")
    
    textfile.close()
    hdulist.close()
sys.setrecursionlimit(50000)
root = tk.Tk()
mainLabel = tk.Label(root, text='MultiMap Conversion Tool')
mainLabel.pack()

mainButton = tk.Button(root, text='Open Fermi LAT FITS File', command=openFile)
mainButton.pack()

root.mainloop()
    


#fits2txt(str(filedialog.askopenfilename()))